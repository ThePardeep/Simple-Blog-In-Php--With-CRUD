<header class="fluid-container header-bg">
    <div class=" container ">
         
         <a href="<?php echo ROOT_PATH; ?>">HOME</a>
         <a href=" <?php echo ROOT_PATH.'addpost.php'; ?>" > ADD POST </a> 

    </div>
</header>