<?php
define("ROOT_PATH", "http://localhost/learn/");
define("CONFIG_PATH", "http://localhost/learn//config");
define("INC_PATH","http://localhost/learn/inc");
?>